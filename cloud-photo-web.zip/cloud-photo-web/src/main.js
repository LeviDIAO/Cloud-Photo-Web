import Vue from 'vue'
import App from './App.vue'

//引入路由
import router from './router'

//全局引入vantui
import Vant from 'vant';
import 'vant/lib/index.css';

// 登录权限设置
import './permission'

//引入vuex
import store from './store'

//引入外部iconfont
import './assets/css/iconfont.css'

Vue.use(Vant);

//适配移动端
import 'lib-flexible';

import fileMd5Sum from '@/utils/fileMd5Sum.js';

Vue.prototype.fileMd5Sum = fileMd5Sum;

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
