//获取用户信息
import request from "@/utils/request";

//获取上传地址
export function getPutUploadUrl(data) {
    return request({
        url: '/api/getPutUploadUrl',
        method: 'post',
        data
    })
}

//提交上传
export function commitUpload(data) {
    return request({
        url: '/api/commitUpload',
        method: 'post',
        data
    })
}

//获取传输列表
export function getTransList() {
    return request({
        url: '/api/getTransList',
        method: 'post'
    })
}
