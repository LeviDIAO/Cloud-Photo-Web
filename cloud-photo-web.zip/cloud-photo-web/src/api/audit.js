import request from "@/utils/request";

//获取审核列表
export function getAuditList(data) {
    return request({
        url: '/audit/getAuditList',
        method: 'post',
        data
    })
}

//更新审核状态
export function updateAuditStatus(data) {
    return request({
        url: '/audit/updateAuditStatus',
        method: 'post',
        data
    })
}
