//提交上传
import request from "@/utils/request";

//获取用户所有照片（分页）
export function getUserAlbumList(data) {
    return request({
        url: '/api/getUserAlbumList',
        method: 'post',
        data
    })
}

//获取用户三种分类的三张照片
export function getAlbumCategorize() {
    return request({
        url: '/api/getAlbumCategorize',
        method: 'get'
    })
}

//获取单个照片的格式分析信息
export function getUserAlbumDetail(data) {
    return request({
        url: '/api/getUserAlbumDetail',
        method: 'post',
        data
    })
}
