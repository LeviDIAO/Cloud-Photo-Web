import request from '@/utils/request'

//获取用户信息
export function getUserInfo() {
  return request({
    url: '/api/getUserInfo',
    method: 'get',
  })
}

//登出
export function logout() {
  return request({
    url: '/api/logout',
    method: 'post',
  })
}

//登录
export function login(data) {
  return request({
    url: '/api/login',
    method: 'post',
    data
  })
}
