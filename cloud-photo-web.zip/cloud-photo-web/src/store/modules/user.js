/**
 * @description 登录、获取用户信息、退出登录、清除token逻辑，不建议修改
 */
import {getUserInfo, logout} from '@/api/user'
import {getToken, removeToken, setToken} from '@/utils/token'
import {isString} from '@/utils/validate'
import {tokenName} from '@/config'
import {Notify} from "vant";
import CloudAvatar from '@/assets/cloud2.png'

const state = () => ({
    department: '',
    userId: undefined,
    token: getToken(),
    phone: '',
    username: '',
    role: '',
    birth: '',
    avatar: CloudAvatar,
})

const getters = {
    department: (state) => state.department,
    userId: (state) => state.userId,
    token: (state) => state.token,
    username: (state) => state.username,
    phone: (state) => state.phone,
    role: (state) => state.role,
    birth: (state) => state.birth,
    avatar: (state) => state.avatar,
}

const mutations = {
    /**
     * @description 设置用户所属地
     * @param {*} state
     * @param {*} department 所属地
     */
    setDepartment(state, department) {
        state.department = department
    },
    /**
     * @description 设置token
     * @param {*} state
     * @param {*} token
     */
    setToken(state, token) {
        state.token = token
        setToken(token)
    },
    /**
     * @description 设置用户名
     * @param {*} state
     * @param {*} username
     */
    setUsername(state, username) {
        state.username = username
    },
    /**
     * @description 设置头像
     * @param {*} state
     * @param {*} avatar
     */
    setAvatar(state, avatar) {
        state.avatar = avatar
    },
    /**
     * @description 设置用户ID
     * @param {*} state
     * @param {*} userId
     */
    setUserId(state, userId) {
        state.userId = userId
    },
    /**
     * @description 设置用户角色
     * @param {*} state
     * @param {*} role
     */
    setRole(state, role) {
        state.role = role
    },
    /**
     * @description 设置生日
     * @param {*} state
     * @param {*} birth
     */
    setBirth(state, birth) {
        state.birth = birth
    },
    /**
     * @description 设置手机号
     * @param {*} state
     * @param {*} phone
     */
    setPhone(state, phone) {
        state.phone = phone
    },
}

const actions = {
    /**
     * @description 登录拦截放行时，设置虚拟角色
     * @param {*} { commit, dispatch }
     */
    setVirtualRoles({commit, dispatch}) {
        dispatch('acl/setFull', true, {root: true})
        commit('setAvatar', CloudAvatar)
        commit('setUsername', 'Aslan')
        commit('setDepartment', '广东省/广州市/天河区')
        commit('setPhone', '15374047317')
        commit('setRole', 'user')
        commit('setBirth', '2023-06-16')
    },
    /**
     * @description 登录
     * @param {*} { commit }
     * @param {*} token
     */
    async login({commit}, token) {
        if (token) {
            commit('setToken', token)
            Notify({type: 'success', message: '登陆成功!'});
        } else {
            const err = `登录接口异常，未正确返回${tokenName}...`
            Notify({type: 'danger', message: err});
            throw err
        }
    },
    /**
     * @description 获取用户信息接口 这个接口非常非常重要，如果没有明确底层前逻辑禁止修改此方法，错误的修改可能造成整个框架无法正常使用
     * @param {*} { commit, dispatch, state }
     * @returns
     */
    async getUserInfo({commit}) {
        const {
            data: {userId, userName, department, phone, role, birth},
        } = await getUserInfo()
        /**
         * 检验返回数据是否正常
         */
        if (
            userId === undefined ||
            (userName && !isString(userName)) ||
            (department && !isString(department)) ||
            (phone && !isString(phone)) ||
            (role && !isString(role)) ||
            (birth && !isString(birth))
        ) {
            const err = '获取登录用户信息失败'
            Notify({type: 'danger', message: err});
            throw err
        } else {
            // 如不使用userName用户名,可删除以下代码
            if (userName) commit('setUsername', userName)
            if (department) commit('setDepartment', department)
            if (phone) commit('setPhone', phone)
            if (userId) commit('setUserId', userId)
            if (role) commit('setRole', role)
            if (birth) commit('setBirth', birth)

        }
    },
    /**
     * @description 退出登录
     * @param {*} { dispatch }
     */
    async logout({dispatch}) {
        return new Promise((resolve, reject) => {
            logout()
                .then((response) => {
                    dispatch('resetAll')
                    resolve(response)
                })
                .catch((error) => {
                    reject(error)
                })
        })
    },
    /**
     * @description 重置token、role、router等
     * @param {*} { commit, dispatch }
     */
    async resetAll({commit, dispatch}) {
        commit('setUsername', '')
        commit('setDepartment', '')
        commit('setPhone', '')
        commit('setUserId', '')
        commit('setRole', '')
        commit('setAvatar', CloudAvatar)
        await dispatch('routes/setRoutes', false, { root: true })
        commit('setToken', null)
        removeToken()
    },
    /**
     * @description 设置token
     * @param {*} { commit }
     * @param {*} token
     */
    setToken({commit}, token) {
        commit('setToken', token)
    },
    /**
     * @description 设置头像
     * @param {*} { commit }
     * @param {*} avatar
     */
    setAvatar({commit}, avatar) {
        commit('setAvatar', avatar)
    },
}

export default {state, getters, mutations, actions}
