/**
 * @description 路由拦截状态管理，目前两种模式：all模式与intelligence模式
 */
import { asyncRoutes, constantRoutes, resetRouter } from '@/router'

const state = () => ({
  routes: []
})

const getters = {
  routes: (state) => state.routes
}

const mutations = {
  /**
   * @description 多模式设置路由
   * @param {*} state
   * @param {*} routes
   */
  setRoutes(state, routes) {
    state.routes = routes
  }
}

const actions = {
  /**
   * @description 多模式设置路由
   * @param {*} { commit }
   * @param isLogin 是否登录
   * @returns
   */
  async setRoutes({ commit }, isLogin) {
    // 前端路由
    let routes = [...asyncRoutes]
    // 所有可访问的路由
    let accessRoutes
    if (isLogin){
      //登陆了可访问全部
      accessRoutes = [...constantRoutes, ...routes]
    }else {
      //没登陆只可访问部分
      accessRoutes = [...constantRoutes]
    }
    // 设置菜单所需路由
    commit('setRoutes', JSON.parse(JSON.stringify(accessRoutes)))
    // 根据可访问路由重置Vue Router
    await resetRouter(accessRoutes)
  }
}

export default { state, getters, mutations, actions }
