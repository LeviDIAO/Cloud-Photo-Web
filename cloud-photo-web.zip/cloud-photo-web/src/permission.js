/**
 * @description 路由守卫
 */
import router from '@/router'
import store from '@/store'
import VabProgress from 'nprogress'
import 'nprogress/nprogress.css'
import getPageTitle from '@/utils/pageTitle'
import {toLoginRoute} from '@/utils/routes'
import {loginInterception, routesWhiteList} from '@/config'

VabProgress.configure({
    easing: 'ease',
    speed: 500,
    trickleSpeed: 200,
    showSpinner: false,
})

router.beforeEach(async (to, from, next) => {
    //开始进度条
    VabProgress.start()
    //是否有token
    let hasToken = store.getters['user/token']
    console.log("hasToken", hasToken)
    //如果没开启登录拦截
    if (!loginInterception) hasToken = true
    //如果有token
    if (hasToken) {
        //有用户信息
        if (store.getters['user/phone'] !== '') {
            // 禁止已登录用户返回登录页
            if (to.path === '/login') {
                next({path: '/'})
                //结束进度条
                VabProgress.done()
            } else next()
        } else {
            try {
                // 重新获取用户信息
                if (loginInterception) await store.dispatch('user/getUserInfo')
                // config/setting.config.js loginInterception为false(关闭登录拦截时)时，创建虚拟角色
                else await store.dispatch('user/setVirtualRoles')
                // 设置权限路由
                await store.dispatch('routes/setRoutes', true)
                next({...to, replace: true})
            } catch (err) {
                console.error('错误拦截:', err)
                //获取用户信息失败就重置信息并返回登陆页
                await store.dispatch('user/resetAll')
                next(toLoginRoute(to.path))
            }
        }
    } else {
        //未登录
        //检查路由白名单
        if (routesWhiteList.includes(to.path)) {
            //如果当前没有路由列表
            if (!store.getters['routes/routes'].length) {
                //获取不用权限校验的路由
                await store.dispatch('routes/setRoutes', false)
                next({ ...to, replace: true })
            } else next()
        } else next(toLoginRoute(to.path))
    }
})

router.afterEach((to) => {
    document.title = getPageTitle(to.meta.title)
    if (VabProgress.status) VabProgress.done()
})
