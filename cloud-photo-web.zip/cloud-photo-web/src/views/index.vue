<template>
  <div>
    <component :is="myComponents"></component>
    <van-tabbar fixed v-model="active" @change="onChange" :placeholder="true">
      <van-tabbar-item icon="photo-o">相册</van-tabbar-item>
      <van-tabbar-item icon="upgrade">传输</van-tabbar-item>
      <van-tabbar-item icon="contact">我的</van-tabbar-item>
      <van-tabbar-item v-if="role === 'admin'" icon="eye-o">审核</van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>

import CloudAlbum from '@/views/album'
import MySelf from '@/views/myself'
import Trans from '@/views/trans'
import Audit from '@/views/audit'
import {mapGetters} from "vuex";


export default {
  name: "index",
  components: {CloudAlbum, MySelf, Trans},
  data(){
    return{
      active: 0,
      myComponents: CloudAlbum
    }
  },
  computed: {
    ...mapGetters({
      role: 'user/role'
    })
  },
  methods: {
    onChange(index) {
      if (index === 0){
        this.myComponents = CloudAlbum
      }else if (index === 1){
        this.myComponents = Trans
      }else if (index === 2){
        this.myComponents = MySelf
      }else if (index === 3){
        this.myComponents = Audit
      }
    },
  },
}
</script>

<style scoped>

</style>
