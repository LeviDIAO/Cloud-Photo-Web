<template>
  <div class="login-container">
    <van-nav-bar border>
      <template #title>
        <span v-if="isAdmin" style="font-size: 22px">管理员登录</span>
        <span v-else style="font-size: 22px">用户登录</span>
      </template>
      <template #right>
        <span v-if="isAdmin" style="font-size: 12px;color: #3d97ef" @click="changeLoginStatus">切换用户登录</span>
        <span v-else style="font-size: 12px;color: #3d97ef" @click="changeLoginStatus">切换管理员登录</span>
      </template>
    </van-nav-bar>

    <div class="login-container-main">

      <van-image
          width="120"
          height="120"
          style="margin-top: 50px"
          :src="logo"
      />

      <van-form style="margin-top: 50px" @submit="login">
        <van-field
            v-if="!isAdmin"
            v-model="userInfo.phone"
            name="phone"
            label="手机号"
            placeholder="请输入手机号"
            :rules="[{ required: true }]"
        />

        <!--        第一次登录-->
        <van-field
            v-if="isNewLogin && !isAdmin"
            v-model="userInfo.userName"
            name="username"
            label="昵称"
            placeholder="请输入昵称(10个字符以内)"
            :rules="[{ required: true }]"
        />
        <van-field
            v-if="isNewLogin && !isAdmin"
            clickable
            name="birth"
            :value="userInfo.birth"
            label="生日"
            placeholder="点击选择出生日期"
            @click="showPicker = true"
        />
        <van-popup v-model="showPicker" position="bottom">
          <van-datetime-picker
              type="date"
              @confirm="onBirthConfirm"
              @cancel="showPicker = false"
          />
        </van-popup>
        <van-field
            v-if="isNewLogin && !isAdmin"
            clickable
            name="department"
            :value="userInfo.department"
            label="所属地"
            placeholder="请选择省市区"
            @click="showArea = true"
            :rules="[{ required: true }]"
        />
        <van-popup v-model="showArea" position="bottom">
          <van-area
              :area-list="areaList"
              @confirm="onAreaConfirm"
              @cancel="showArea = false"
          />
        </van-popup>

        <!--        管理员登录-->
        <van-field
            v-if="isAdmin"
            v-model="userInfo.userName"
            name="username"
            label="账号"
            placeholder="请输入管理员账号(admin)"
            :rules="[{ required: true }]"
        />
        <van-field
            v-if="isAdmin"
            v-model="userInfo.password"
            name="password"
            type="password"
            label="密码"
            placeholder="请输入管理员密码(admin)"
            :rules="[{ required: true }]"
        />

        <div style="margin: 16px;">
          <van-button :loading="loginLoading" round block type="info" native-type="submit">提交</van-button>
        </div>

      </van-form>
    </div>

    <VabFooter></VabFooter>

  </div>
</template>

<script>
import {login} from "@/api/user";
import CloudLogo from '@/assets/cloud.png'
import AdminLogo from '@/assets/admin.png'
import VabFooter from "components/VabFooter";
import {areaList} from '@vant/area-data';
import moment from "moment";
import {mapActions} from "vuex";

export default {
  name: "login",
  components: {VabFooter},
  data() {
    return {
      CloudLogo,
      AdminLogo,
      //是否为管理员登录
      isAdmin: false,
      //logo图
      logo: CloudLogo,
      //登录loading
      loginLoading: false,
      //标志一下是否是第一次登录
      isNewLogin: false,
      //展示所属地选择框
      showArea: false,
      //展示时间选择框
      showPicker: false,
      areaList, // 数据格式见 Area 组件文档
      //用户信息
      userInfo: {
        phone: undefined,
        password: undefined,
        birth: undefined,
        department: undefined,
        userName: undefined,
        role: undefined
      }
    }
  },
  methods: {
    ...mapActions({
      userLogin: 'user/login',
    }),

    //生日选择
    onBirthConfirm(time) {
      this.userInfo.birth = moment(time).format('YYYY-MM-DD');
      this.showPicker = false;
    },

    //用户归属地选择
    onAreaConfirm(values) {
      this.userInfo.department = values.map((item) => item.name).join('/');
      this.showArea = false;
    },
    //登录
    login() {
      this.loginLoading = true
      //用户角色
      this.userInfo.role = this.isAdmin ? 'admin' : 'user'
      //执行登录
      login(this.userInfo).then(res => {
        if (res.code === 200) {
          //拿到后端传来的token
          const token = res.data
          setTimeout(() => {
            this.loginLoading = false
            //存储token并跳转页面
            this.$store.dispatch('user/login', token).then(() =>
                //跳转到首页
                this.$router.push({path: '/'}).then(() => {
                })
            )
          }, 1000)
        } else {
          setTimeout(() => {
            this.loginLoading = false
          }, 500)
        }
      }).catch(error => {
        if (error.code === 90401) {
          //第一次登录
          this.isNewLogin = true
          setTimeout(() => {
            this.loginLoading = false
          }, 500)
        } else {
          setTimeout(() => {
            this.loginLoading = false
          }, 500)
        }
      })
    },

    //切换管理员登录
    changeLoginStatus() {
      this.isAdmin = !this.isAdmin
      this.logo = this.isAdmin ? AdminLogo : CloudLogo
    }
  }
}
</script>

<style scoped lang="scss">

::v-deep .van-nav-bar__content {
  height: 100px;
}

$base: '.login-container';

#{$base} {
  width: 100%;
  height: 100%;

  #{$base}-main {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
  }
}


</style>
