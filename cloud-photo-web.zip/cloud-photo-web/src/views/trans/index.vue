<template>
  <div>
    <van-nav-bar border>
      <template #title>
        <span style="font-weight: bold;font-size: 22px">传输管理</span>
      </template>
    </van-nav-bar>

    <van-tabs v-model="active" animated>
      <van-tab title="传输中">
        <van-list
            v-model="loading"
            :finished="finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <van-cell size="large" v-for="item in traningList" :key="item.fileName">
            <template #title>
              <div style="display: flex; align-items: center">
                <van-icon name="photo-o" size="20px" color="#OOOOO0" style="margin-right: 10px"/>
                <div
                    style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;width: 250px;text-align: left">
                  <span style="font-weight: bold; font-size: 14px">{{ item.fileName }}</span>
                </div>
              </div>
            </template>
            <template #extra>
              <span style="color: blue">上传中</span>
            </template>
          </van-cell>
        </van-list>
      </van-tab>
      <van-tab title="已完成">
        <van-list
            v-model="loading"
            :finished="finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <van-cell size="large" v-for="item in overList" :key="item.fileName" :label="item.uploadTime">
            <template #title>
              <div style="display: flex; align-items: center">
                <van-icon name="photo-o" size="20px" color="#OOOOO0" style="margin-right: 10px"/>
                <div
                    style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;width: 250px;text-align: left">
                  <span style="font-weight: bold; font-size: 14px">{{ item.fileName }}</span>
                </div>
              </div>
            </template>
            <template #extra>
              <span v-if="item.status === '1'" style="color: green">上传成功</span>
              <span v-if="item.status === '-1'" style="color: red">上传失败</span>
            </template>
          </van-cell>
        </van-list>
      </van-tab>
    </van-tabs>

    <VabFooter></VabFooter>
  </div>
</template>

<script>
import VabFooter from "components/VabFooter";
import {getTransList} from "@/api/trans";

export default {
  name: "trans",
  components: {VabFooter},
  data() {
    return {
      active: 0,
      //传输已完成或失败的列表
      overList: [],
      //传输中的列表
      traningList: [],
      loading: false,
      finished: false,
    }
  },
  created() {
    this.getTransList()
  },
  methods: {

    //获取传输列表
    getTransList(){
      getTransList().then(res => {
        console.log("getTransList", res)
        if (res.code === 200){

          //数据排个序

          this.overList = res.data.filter(item => item.status === '1' || item.status === '-1')
          this.traningList = res.data.filter(item => item.status === '0')
        }
      })
    },

    onLoad() {

        // 加载状态结束
        this.loading = false;
        // 数据全部加载完成
        this.finished = true;

    },
  }
}
</script>

<style scoped lang="scss">

::v-deep .van-nav-bar__content {
  height: 100px;
}


</style>




