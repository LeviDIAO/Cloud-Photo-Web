<template>
  <div>

    <van-nav-bar border>
      <template #title>
        <span style="font-weight: bold;font-size: 22px">审核列表</span>
      </template>
    </van-nav-bar>

    <van-tabs v-model="active" animated @change="changeAuditList">
      <van-tab title="待审核">
        <van-skeleton v-if="pageLoading" style="margin-top: 20px" title :row="3" :loading="pageLoading"/>
        <div v-else>
          <van-empty v-if="list.length  === 0" description="暂无待审核列表"/>
          <van-checkbox-group v-else v-model="result" ref="checkboxGroup">
            <div style="display: flex;margin-left: 10px;padding-top: 20px">
              <van-button type="primary" size="mini" @click="checkAll">全选</van-button>
              <van-button type="info" size="mini" @click="toggleAll">反选</van-button>
              <van-button v-if="result.length > 0" type="danger" size="mini" @click="changeAuditResultBatch(2)">一键拉黑
              </van-button>
              <van-button v-if="result.length > 0" type="primary" size="mini" @click="changeAuditResultBatch(1)">一键通过
              </van-button>
            </div>

            <van-cell v-for="item in list" :key="item.fileAuditId">
              <template #title>
                <div
                    style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;width: 150px;text-align: left;margin-left: 20px">
                  <span style="">{{ item.fileName }}</span>
                </div>
              </template>
              <template #label>
                <span style="color: green;margin-left: 20px">自动审核成功</span>
                <span style="color: black;margin-left: 10px">人工未审核</span>
              </template>
              <template #extra>
                <div style="display: flex;align-items: center">
                  <van-button type="warning" size="mini" @click="seePicture(item)">查看大图</van-button>
                  <van-button type="danger" size="mini" @click="changeAuditResult(item, 2)">拉黑</van-button>
                  <van-button type="primary" size="mini" @click="changeAuditResult(item, 1)">通过</van-button>
                </div>
              </template>
              <template #icon>
                <van-checkbox :name="item" ref="checkboxes"/>
              </template>
            </van-cell>
          </van-checkbox-group>
          <!--    分页组件-->
          <van-pagination v-if="list.length > 0" v-model="formData.current" :page-count="pages" mode="simple"
                          @change="changePage"/>
        </div>
      </van-tab>

      <van-tab title="已审核">
        <van-skeleton v-if="pageLoading" style="margin-top: 20px" title :row="3" :loading="pageLoading"/>
        <div v-else>
          <van-empty v-if="list.length === 0" description="暂无已审核列表"/>
          <van-cell v-else v-for="item in list" :key="item.fileAuditId">
            <template #title>
              <div
                  style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;width: 250px;text-align: left;margin-left: 20px">
                <span style="">{{ item.fileName }}</span>
              </div>
            </template>
            <template #label>
                <span style="color: green;margin-left: 20px">
                  自动审核成功
                </span>
              <span v-if="item.auditStatus === 1" style="color: green;margin-left: 10px">人工审核成功</span>
              <span v-if="item.auditStatus === 2" style="color: red;margin-left: 10px">人工审核不通过</span>
            </template>
          </van-cell>
          <!--    分页组件-->
          <van-pagination v-if="list.length > 0" v-model="formData.current" :page-count="pages" mode="simple"
                          @change="changePage"/>
        </div>
      </van-tab>
    </van-tabs>
  </div>
</template>

<script>
import {getAuditList, updateAuditStatus} from "@/api/audit";
import {ImagePreview, Notify} from "vant";
import {baseURL} from "@/config";
import moment from "moment";

export default {
  name: "Audit",
  data() {
    return {
      //待审核列表
      list: [],

      //标签
      active: 0,

      //多选选项列表
      result: [],

      //审核页加载
      pageLoading: false,

      //请求表单
      formData: {
        current: 1,
        pageSize: 10,
        auditStatusList: undefined,
        fileAuditIds: undefined,
      },

      //总页数
      pages: 0,
    }
  },
  created() {
    //获取审核列表
    this.fetchAuditList([0])
  },
  methods: {

    //改变页码
    changePage(){
      if (this.active === 0) {
        //待审核
        this.fetchAuditList([0])
      } else if (this.active === 1) {
        //已审核
        this.fetchAuditList([1, 2])
      }
    },

    //标签切换：根据标签类型不同获取审核列表
    changeAuditList() {
      //初始化页码
      this.formData.current = 1
      if (this.active === 0) {
        //待审核
        this.fetchAuditList([0])
      } else if (this.active === 1) {
        //已审核
        this.fetchAuditList([1, 2])
      }
    },

    //获取审核列表
    fetchAuditList(status) {
      this.pageLoading = true
      this.formData.auditStatusList = status
      getAuditList(this.formData).then(res => {
        console.log("getAuditList", res)
        this.list = res.data.records
        this.pages = res.data.pages
        setTimeout(() => {
          this.pageLoading = false
        }, 500)
      })
    },

    //单个修改审核状态
    changeAuditResult(item, status) {
      this.formData.auditStatus = status
      this.formData.fileAuditIds = [item.fileAuditId]
      updateAuditStatus(this.formData).then(res => {
        console.log("updateAuditStatus", res)
        if (res.code === 200) {
          //更新列表
          Notify({type: 'success', message: '操作成功!'});
          this.fetchAuditList()
        }
      })
    },

    //批量修改审核状态
    changeAuditResultBatch(status) {
      this.formData.auditStatus = status
      this.formData.fileAuditIds = this.result.map(item => item.fileAuditId)
      updateAuditStatus(this.formData).then(res => {
        console.log("updateAuditStatus", res)
        if (res.code === 200) {
          //更新列表
          Notify({type: 'success', message: '操作成功!'});
          this.fetchAuditList()
        }
      })
    },

    //全选
    checkAll() {
      this.$refs.checkboxGroup.toggleAll(true);
    },

    //反选
    toggleAll() {
      this.$refs.checkboxGroup.toggleAll();
    },

    //审核查看大图
    seePicture(item) {
      ImagePreview([
        baseURL + '/api/previewImage?fileId=' + item.userFileId + '&iconCode=600_600&timestamp=' + moment()
      ]);
    }
  }
}
</script>

<style scoped lang="scss">
::v-deep .van-nav-bar__content {
  height: 100px;
}
</style>
