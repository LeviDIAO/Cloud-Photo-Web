<template>
  <div>
    <van-nav-bar border :placeholder="true" fixed>
      <template #title>
        <span style="font-weight: bold;font-size: 22px">相册</span>
      </template>
      <template #right>
        <picture-upload @getData="getData"></picture-upload>
      </template>
    </van-nav-bar>

    <div class="picture-container-main">
      <!--      我的照片分类-->
      <van-cell size="large" :border="false">
        <template #title>
          <span style="font-weight: bold">我的照片分类</span>
        </template>
      </van-cell>
      <van-grid column-num="3" :border="false" square>
        <van-grid-item v-for="(item, index) in pictureCateList" :key="index"
                       @click="seePictureByCategory(item.category)">
          <div style="width: 100%; height: 100%; display: flex">
            <div style="width: 66.66%;height: 100%">
              <van-image
                  width="100%"
                  height="100%"
                  fit="cover"
                  :src="item.list[0]"
              />
            </div>
            <div style="width: 33.33%;height: 100%">
              <div style="width: 100%;height: 50%">
                <van-image
                    width="100%"
                    height="100%"
                    fit="cover"
                    :src="item.list[1]"
                />
              </div>
              <div style="width: 100%;height: 50%">
                <van-image
                    width="100%"
                    height="100%"
                    fit="cover"
                    :src="item.list[2]"
                />
              </div>
            </div>
          </div>
          <div style="width: 100%;padding-top: 5px; display: flex;flex-direction: column;align-items: flex-start">
            <span>{{ item.type }}</span>
            <span style="color: #bbb1b1">{{ item.num }}</span>
          </div>
        </van-grid-item>
      </van-grid>

      <!--      我的照片-->
      <van-cell size="large" :border="false">
        <template #title>
          <span style="font-weight: bold">我的照片</span>
        </template>
        <template #right-icon>
          <div style="display: flex;align-items: center">
            <span style="font-weight: bold; font-size: 12px;color: #a39a9a" @click="seeMorePicture">更多</span>
            <van-icon name="arrow" size="12px" color="#a39a9a"/>
          </div>
        </template>
      </van-cell>
      <van-grid column-num="4" :border="false" square class="main-all-picture">
        <van-grid-item v-for="(item, index) in pictureList" :key="index">
          <van-image @click="() => seePicture(index)" width="100%" height="100%" fit="cover" :src="item.fileUrl"/>
        </van-grid-item>
      </van-grid>
    </div>

    <!--    注册图片预览框-->
    <VabPicturePreview ref="preview"></VabPicturePreview>

    <!--    注册底部copyright-->
    <VabFooter></VabFooter>
  </div>
</template>

<script>
import VabFooter from "components/VabFooter";
import {ImagePreview} from 'vant';
import VabPicturePreview from "components/VabPicturePreview";
import PictureUpload from "@/views/album/components/PictureUpload";
import {getAlbumCategorize, getUserAlbumList} from "@/api/album";
import {baseURL} from '@/config'
import moment from "moment";

export default {
  name: "album",
  components: {PictureUpload, VabPicturePreview, VabFooter},
  data() {
    return {
      //分页Bo
      albumPageBo: {
        current: 1,
        pageSize: 20,
        category: ''
      },

      //照片分类信息
      pictureCateList: [],
      //我的照片
      pictureList: [],
    }
  },
  created() {
    this.getData()
  },
  methods: {
    ImagePreview,
    //获取相册页数据
    getData() {
      this.getUserAlbumList()
      this.getAlbumCategorize()
    },
    //获取主页最近上传的20张照片
    getUserAlbumList() {
      this.pictureList = []
      getUserAlbumList(this.albumPageBo).then(res => {
        console.log("getUserAlbumList", res)
        if (res.code === 200) {
          let list = res.data.records
          list.forEach(item => {
            item.fileUrl = baseURL + '/api/previewImage?fileId=' + item.userFileId + '&iconCode=200_200&timestamp=' + moment()
            item.bigFileUrl = baseURL + '/api/previewImage?fileId=' + item.userFileId + '&iconCode=600_600&timestamp=' + moment()
          })
          this.pictureList = list
        }
      })
    },
    //获取主页用户三种分类的三张图片
    getAlbumCategorize() {
      this.pictureCateList = []
      getAlbumCategorize().then(res => {
        console.log("getAlbumCategorize", res)
        if (res.code === 200) {
          let map = res.data
          let locationList = map['location'].data.records.map(item => baseURL + '/api/previewImage?fileId=' + item.userFileId + '&iconCode=200_200&timestamp=' + moment())
          let personList = map['person'].data.records.map(item => baseURL + '/api/previewImage?fileId=' + item.userFileId + '&iconCode=200_200&timestamp=' + moment())
          let thingList = map['thing'].data.records.map(item => baseURL + '/api/previewImage?fileId=' + item.userFileId + '&iconCode=200_200&timestamp=' + moment())

          this.pictureCateList = [{
            category: 1,
            type: '人物',
            num: map['person'].data.total,
            list: personList
          }, {
            category: 2,
            type: '地点',
            num: map['location'].data.total,
            list: locationList
          }, {
            category: 3,
            type: '事物',
            num: map['thing'].data.total,
            list: thingList
          }]
        }
      })
    },
    //查看我的全部照片
    seeMorePicture() {
      this.$router.push("/picture/all")
    },
    //查看某个分类下的所有照片
    seePictureByCategory(category) {
      this.$router.push({path: '/picture/category', query: {category: category}})
    },
    //查看图片
    seePicture(index) {
      this.$refs['preview'].openPreview(index, this.pictureList)
    }
  }
}
</script>

<style scoped lang="scss">

$base: '.picture-container';

::v-deep .van-nav-bar__content {
  background-color: #FFFAFA;
  height: 100px;
}

::v-deep .van-nav-bar__title {
  margin: 0 30px;
}

#{$base}-main {

  .main-all-picture {
    ::v-deep .van-grid-item__content {
      padding: 0;
    }
  }
}

#{$base}-popup {
  padding-top: 100px;
  width: 100%;
  height: 100%;
}


</style>
