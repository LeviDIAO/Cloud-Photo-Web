<template>
  <div>
    <van-uploader v-model="fileList" :before-read="beforeRead" :after-read="afterRead" multiple result-type="file" :preview-image="false">
      <van-button icon="plus" type="default" color="#FFFAFA">
        <template #icon>
          <van-icon class-prefix="my-icon" name="upload" size="25px" color="#000000" style="font-weight: bold"/>
        </template>
      </van-button>
    </van-uploader>
    <van-dialog v-model="show" title="请选择标签" show-cancel-button show-confirm-button @confirm="handlePictureUpload">
      <div style="width: 100%; height: 100px;padding: 20px;display: flex;flex-direction: column;align-items: flex-start;justify-content: center">
        <span style="margin-bottom: 30px">你选择了{{ fileList.length }}张图片，请选择标签：</span>
        <van-radio-group v-model="category" direction="horizontal">
          <van-radio name="1" shape="square">人物</van-radio>
          <van-radio name="2" shape="square">地点</van-radio>
          <van-radio name="3" shape="square">事物</van-radio>
        </van-radio-group>
      </div>
    </van-dialog>
  </div>
</template>

<script>

import {Notify, Toast} from 'vant';
import {commitUpload, getPutUploadUrl} from "@/api/trans";
import axios from 'axios'

export default {
  name: "PictureUpload",
  data() {
    return {
      fileList: [],
      fileListTemp: {},
      show: false,
      category: 1
    }
  },
  methods: {
    // 文件读取前置处理 - 要返回布尔值
    beforeRead(file) {
      console.log("file", file)
      //每次上传都清空一下
      this.fileList = []
      //如果选了多个图片
      if (file instanceof Array && file.length > 0) {
        //循环每一个文件
        for (const item in file) {
          //如果上传的不是图片就pass
          if (file[item].type !== 'image/jpeg' && file[item].type !== 'image/png') {
            Toast('请上传 jpg、png 格式图片');
            return false;
          }
        }
      } else {
        //如果上传的不是图片就pass
        if (file.type !== 'image/jpeg' && file.type !== 'image/png') {
          Toast('请上传 jpg、png 格式图片');
          return false;
        }
      }
      return true;
    },

    //文件读取成功后
    afterRead(){
      this.show = true
    },

    //处理文件上传
    handlePictureUpload(){
      //生成文件md5
      this.fileList.forEach(item => {
        let file= item.file
        this.fileMd5Sum.fileMd5Sum(file).then(res => {
          let data = {fileName: file.name, fileMd5: res, fileSize: file.size, category: this.category}
          this.fileListTemp[res] = file
          //获取上传地址
          this.getPutUploadUrl(data)
        });
      })
    },

    //获取上传地址
    getPutUploadUrl(data) {
      getPutUploadUrl(data).then(res => {
        console.log("getPutUploadUrl", res)
        if (res.code === 200) {
          //获取上传地址成功 - 就把文件加到待传输列表
          if (res.data.storageObjectId) {
            //秒传 - 直接提交
            this.handleCommitUpload(res.data)
          } else {
            //非妙传 - 直接上传
            let md5 = res.data.fileMd5
            let url = res.data.uploadUrl
            let base64Md5 = res.data.base64Md5
            //找到这个文件的file本体
            let filter = this.fileListTemp[md5]
            //上传文件到资源池
            this.uploadFileToOoS(filter, url, base64Md5, res.data)
          }
        }
      })
    },

    //上传文件到资源池
    uploadFileToOoS(file, url, md5, data) {
      axios({
        url: url,
        method: 'put',
        data: file,
        headers: {
          'Content-MD5': md5,
          'Content-Type': 'application/octet-stream'
        }
      }).then((res) => {
        console.log("uploadFileToOoS", res)
        //返回上传到资源池的结果
        if (res.status === 200){
          //如果成功了直接提交
          this.handleCommitUpload(data)
        }
      })
    },

    //处理提交上传
    handleCommitUpload(data){
      commitUpload(data).then(res => {
        console.log("commitUpload", res)
        if (res.code === 200){
          Notify({type: 'success', message: '上传成功'});
          this.$emit('getData')
        }
      })
    }
  }
}
</script>

<style scoped>

</style>
