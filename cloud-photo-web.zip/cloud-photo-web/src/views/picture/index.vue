<template>
  <div class="picture-container">
    <van-nav-bar border left-arrow :placeholder="true" fixed @click-left="back">
      <template #title>
        <span style="font-weight: bold;font-size: 22px">我的所有照片</span>
      </template>
      <template #left>
        <van-icon name="arrow-left" style="font-weight: bold;" size="22px" color="#8F8F8F"/>
      </template>
    </van-nav-bar>

    <van-pull-refresh v-model="isRefresh" @refresh="onRefresh" success-text="刷新成功">

      <div class="picture-container-main">
        <van-list
            v-model="loading"
            :finished="finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div v-for="(value, key) in list" :key="key">
            <van-cell size="large" :border="false">
              <template #title>
                <span style="font-weight: bold">{{ key }}</span>
              </template>
            </van-cell>
            <van-grid column-num="4" :border="false" square class="main-all-picture">
              <van-grid-item v-for="item in value" :key="item.index">
                <van-image @click="() => seePicture(item.index)" width="100%" height="100%" fit="cover" :src="item.fileUrl"/>
              </van-grid-item>
            </van-grid>
          </div>

        </van-list>
      </div>

      <vab-footer></vab-footer>

    </van-pull-refresh>

    <!--    注册图片预览框-->
    <VabPicturePreview ref="preview"></VabPicturePreview>

  </div>
</template>

<script>
import {getUserAlbumList} from "@/api/album";
import VabFooter from "components/VabFooter";
import VabPicturePreview from "components/VabPicturePreview";
import {baseURL} from "@/config";
import moment from "moment";

export default {
  name: "picture",
  components: {VabFooter, VabPicturePreview},
  data() {
    return {
      formData: {
        current: 1,
        pageSize: 10,
        category: undefined
      },

      //绑定刷新状态
      isRefresh: false,

      //分组前的列表数据
      beforeList: [],

      //分组后的列表数据
      list: {},
      //列表是否加载
      loading: false,
      //列表是否加载完成
      finished: false,

      //类型：标志是看全部还是某个分类的
      type: '',
      //记录下图片的索引
      index: 0
    }
  },
  watch: {
    $route: {
      handler(route) {
        this.type = route.params.type
        if (this.type === 'category') {
          this.formData.category = route.query.category
        }
      },
      immediate: true,
    },
  },
  created() {
    this.getAllUserAlbumList()
  },
  methods: {

    //下拉刷新回调
    onRefresh() {
      //给数据清空一下：不然数据会重复错乱
      this.list = {}
      this.index = 0
      this.formData.current = 1
      this.loading = true
      this.finished = false
      this.beforeList = []
      this.getAllUserAlbumList()
      this.isRefresh = false;
    },

    //获取当前用户所有的照片
    getAllUserAlbumList() {
      //开启加载
      this.loading = true
      getUserAlbumList(this.formData).then(res => {
        console.log("getUserAlbumList", res)
        let list = res.data.records
        if (list.length === 0) {
          this.finished = true
        }

        let map = this.list
        //遍历数据做处理
        list.forEach(item => {
          //分组前的数据
          this.beforeList.push(item)
          //生成大图小图
          item.index = this.index
          item.fileUrl = baseURL + '/api/previewImage?fileId=' + item.userFileId + '&iconCode=200_200&timestamp=' + moment()
          item.bigFileUrl = baseURL + '/api/previewImage?fileId=' + item.userFileId + '&iconCode=600_600&timestamp=' + moment()
          //提取前面日期
          let time = item.createTime.substring(0, 10)
          // eslint-disable-next-line no-prototype-builtins
          if (map.hasOwnProperty(time)) {
            //有这个key
            map[time].push(item)
          } else {
            //没有这个key
            map[time] = [item]
          }
          //图片索引+1
          this.index++
        })

        setTimeout(() => {
          this.loading = false
          this.list = map
        }, 1000)
      })
    },

    //列表异步加载数据
    onLoad() {

      //页码+1
      this.formData.current++
      //重复请求数据
      this.getAllUserAlbumList()
    },

    //查看图片
    seePicture(index) {
      this.$refs['preview'].openPreview(index, this.beforeList)
    },

    //回退到上一页
    back() {
      this.$router.back()
    }
  }
}
</script>

<style scoped lang="scss">

::v-deep .van-nav-bar__content {
  background-color: #FFFAFA;
  height: 100px;
}

$base: '.picture-container';

#{$base}-main {

  .main-all-picture {
    ::v-deep .van-grid-item__content {
      padding: 1px;
    }
  }
}
</style>
