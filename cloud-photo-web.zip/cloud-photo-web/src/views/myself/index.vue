<template>
  <div>
    <div class="myself-container">
      <div class="myself-container-avatar">
        <van-image
            class="myself-container-avatar-image"
            round
            width="100px"
            height="100px"
            :src="avatar"
        />
      </div>
      <div class="myself-container-userinfo">
        <span style="font-weight: bold;font-size: 30px; margin-bottom: 10px">{{ username }}</span>
      </div>
    </div>
    <div class="myself-container-menu">
      <van-cell-group>
        <van-cell is-link size="large" clickable @click="seeUserInfo">
          <template #title>
            <div style="display: flex; align-items: center">
              <van-icon name="friends" size="25px" color="#33ccff" style="margin-right: 20px"/>
              <span style="font-weight: bold">个人信息</span>
            </div>
          </template>
        </van-cell>
<!--        <van-cell is-link size="large" clickable @click="toExaminePage">-->
<!--          <template #title>-->
<!--            <div style="display: flex; align-items: center">-->
<!--              <van-icon name="browsing-history" size="25px" color="#0A0A0A" style="margin-right: 20px"/>-->
<!--              <span style="font-weight: bold">审核记录</span>-->
<!--            </div>-->
<!--          </template>-->
<!--        </van-cell>-->
        <van-cell is-link size="large" clickable @click="logout">
          <template #title>
            <div style="display: flex; align-items: center">
              <van-icon name="clear" size="25px" color="#ff3333" style="margin-right: 20px"/>
              <span style="font-weight: bold">退出登录</span>
            </div>
          </template>
        </van-cell>
      </van-cell-group>
    </div>
    <van-popup v-model="openPopup" position="bottom" :style="{ height: '40%' }">
      <van-skeleton style="margin-top: 20px" title :row="3" :loading="loading" />
      <van-cell-group v-if="!loading">
        <van-field label="手机号" :value="phone" readonly />
        <van-field label="用户名" :value="username" readonly />
        <van-field label="归属地" :value="department" readonly />
        <van-field label="用户角色" :value="role" readonly />
        <van-field label="出生日期" :value="moment(birth).format('YYYY-MM-DD')" readonly />
      </van-cell-group>
    </van-popup>

    <VabFooter></VabFooter>
  </div>
</template>

<script>
import {mapGetters} from 'vuex'
import {Dialog} from "vant";
import VabFooter from "components/VabFooter";
import {logout} from "@/api/user";
import moment from "moment";

export default {
  name: "myself",
  components: {VabFooter},
  data() {
    return {
      show: false,
      openPopup: false,
      loading: true,
    }
  },
  computed: {
    ...mapGetters({
      phone: 'user/phone',
      birth: 'user/birth',
      username: 'user/username',
      department: 'user/department',
      avatar: 'user/avatar',
      role: 'user/role',
    }),
  },
  methods: {
    moment,
    //查看个人信息
    seeUserInfo(){
      this.openPopup = true
      setTimeout(() => {
        this.loading = false
      }, 2000)
    },

    //退出登录
    logout() {
      Dialog.confirm({
        title: '退出登录',
        message: '你确定要退出登录吗？'
      })
          .then(() => {
            logout().then(res => {
              console.log("logout", res)
              if (res.code === 200) {
                this.$store.dispatch('user/resetAll').then(() =>
                    this.$router.push({path: '/login', replace: true}).then(() => {
                    })
                )
              }
            })
          })
          .catch(() => {
            // on cancel
          });
    }
  }

}
</script>

<style scoped lang="scss">

$base: '.myself-container';

#{$base} {
  width: 100%;
  height: 300px;
  background-color: #99ccff;
  display: flex;

  #{$base}-avatar {
    width: 30%;
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  #{$base}-userinfo {
    padding: 20px;
    width: 70%;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
}

#{$base}-menu {
  width: 100%;
  height: 100%;
  margin-top: 40px;
}

</style>
