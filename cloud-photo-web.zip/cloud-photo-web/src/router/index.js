/**
 * @description router全局配置
 */
import Vue from 'vue'
import VueRouter from 'vue-router'
import { publicPath, routerMode } from '@/config'

Vue.use(VueRouter)

//无需校验的路由
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login'),
  },
  {
    path: '/404',
    component: () => import('@/views/404'),
  }
]

//需要校验的路由
export const asyncRoutes = [
  {
    path: '/',
    name: 'Index',
    component: () => import('@/views/index'),
    meta: {
      title: '云盘(简易版)'
    },
  },
  {
    path: '/picture/:type',
    name: 'Picture',
    component: () => import('@/views/picture'),
    meta: {
      title: '我的全部照片'
    },
  },
  {
    path: '/audit',
    name: 'Audit',
    component: () => import('@/views/audit'),
    meta: {
      title: '审核'
    },
  },
  {
    path: '*',
    redirect: '/404',
    meta: {
      hidden: true,
    },
  },
]

const router = createRouter()

//拼接children子路由
function fatteningRoutes(routes) {
  return routes.flatMap((route) => {
    return route.children ? fatteningRoutes(route.children) : route
  })
}

//重新生成路由
export function resetRouter(routes = constantRoutes) {
  routes.map((route) => {
    if (route.children) {
      route.children = fatteningRoutes(route.children)
    }
  })
  router.matcher = createRouter(routes).matcher
}

//创建路由
function createRouter(routes = constantRoutes) {
  return new VueRouter({
    base: publicPath,
    mode: routerMode,
    scrollBehavior: () => ({
      y: 0,
    }),
    routes: routes,
  })
}

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch((err) => err)
}

//导出路由
export default router
