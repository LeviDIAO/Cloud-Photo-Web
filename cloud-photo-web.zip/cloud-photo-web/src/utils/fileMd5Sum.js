export default {
    // md5值计算
    fileMd5Sum(file) {
        let CryptoJS = require("crypto-js");
        return new Promise(resolve => {
            const fileReader = new FileReader();
            fileReader.onloadend = ev => {
                resolve(
                    CryptoJS.MD5(CryptoJS.enc.Latin1.parse(ev.target.result)).toString(
                        CryptoJS.enc.Hex
                    )
                );
            };
            fileReader.readAsBinaryString(file);
        });
    }
}
