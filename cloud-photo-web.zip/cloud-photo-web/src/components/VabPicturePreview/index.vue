<template>
  <div>
    <van-image-preview v-model="show" :images="images" :show-index="false" @change="onChange" asyncClose
                       :start-position="startPosition">
      <template #cover>
        <div style="margin: 0 auto;width: 90%;height: 100px;">
          <div style="width: 100%;height: 50px;display: flex;justify-content: space-between;align-items: center">
            <van-icon name="clear" color="#eee7e7" size="24px" @click="show=false"/>
            <div
                style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;width: 250px;color: #eee7e7;text-align: center">
              <span style="font-size: 18px;font-weight: bold;">{{
                  pictureList[index - 1].fileName
                }}</span>
            </div>
            <van-icon name="info" color="#eee7e7" size="24px" @click="seePictureDetail"/>
          </div>
          <div style="width: 100%;height: 50px;text-align: center">
            <span style="color: #eee7e7;font-size: 16px;font-weight: bold">{{ index + ' / ' + images.length }}</span>
          </div>
        </div>
      </template>
    </van-image-preview>

    <van-popup v-model="openPopup" position="bottom" :style="{ height: '40%' }">
      <van-skeleton style="margin-top: 20px" title :row="3" :loading="loading"/>
      <van-cell-group v-if="!loading">
        <van-field label="分类标签" :value="getCategory(pictureList[index-1].category)" readonly/>
        <van-field label="文件名称" :value="pictureList[index-1].fileName" readonly/>
        <van-field label="拍摄时间" :value="fileInfo ? fileInfo.shootingTime: pictureList[index-1].createTime.replace('T', ' ')" readonly/>
        <van-field label="上传时间" :value="pictureList[index-1].createTime.replace('T', ' ')" readonly/>
        <van-field label="图片大小" :value="getFileSize(pictureList[index-1].fileSize)" readonly/>
        <van-field label="图片尺寸" :value="fileInfo ? fileInfo.width + 'x' + fileInfo.height : ''" readonly/>
      </van-cell-group>

    </van-popup>

  </div>
</template>

<script>
import {getUserAlbumDetail} from "@/api/album";

export default {
  name: "VabPicturePreview",
  data() {
    return {
      show: false,
      pictureList: [],
      images: [],
      index: 0,
      //开始点位
      startPosition: 1,
      //打开文件信息弹窗
      openPopup: false,
      //文件信息加载
      loading: true,
      //文件信息实体
      fileInfo: undefined
    }
  },
  methods: {

    //打开图片预览
    openPreview(index, images) {
      console.log("openPreview", index, images)
      this.pictureList = images
      this.images = images.map(item => item.bigFileUrl)
      this.startPosition = index
      this.index = this.startPosition + 1
      this.show = true
    },

    //获取标签
    getCategory(category) {
      if (category === 1) {
        return '人物'
      }
      if (category === 2) {
        return '地点'
      }
      if (category === 3) {
        return '事物'
      }
    },

    //获取文件大小
    getFileSize(fileSize) {
      if (fileSize / 1024 / 1024 > 1) {
        return (fileSize / 1024 / 1024).toFixed(2) + " M"
      } else if (fileSize / 1024 > 1) {
        return (fileSize / 1024).toFixed(2) + " K"
      } else {
        return fileSize + ' B'
      }

    },

    //切换监听
    onChange(num) {
      this.index = num + 1
    },

    //查看图片详情信息
    seePictureDetail() {
      this.openPopup = true
      const fileId = this.pictureList[this.index - 1].userFileId
      getUserAlbumDetail({fileId: fileId}).then(res => {
        console.log("getUserAlbumDetail", res)
        if (res.code === 200) {
          this.fileInfo = res.data
        }
        setTimeout(() => {
          this.loading = false
        }, 2000)
      })

    }
  }
}
</script>

<style scoped lang="scss">

::v-deep .van-nav-bar__content {
  width: 100%;
  height: 100px;

}

::v-deep .van-image-preview__cover {
  width: 100%;
}

</style>
