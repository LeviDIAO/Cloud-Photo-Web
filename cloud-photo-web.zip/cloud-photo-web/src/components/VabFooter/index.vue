<template>
  <footer class="vab-footer">
    Copyright
    <van-icon class-prefix="my-icon" name="copyright" />
    {{ fullYear }} XXXXX - {{ title }}
  </footer>
</template>

<script>
  import { title } from '@/config'

  export default {
    name: 'VabFooter',
    data() {
      return {
        fullYear: new Date().getFullYear(),
        title,
      }
    },
  }
</script>

<style lang="scss" scoped>
  .vab-footer {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 55px;
    padding: 20px;
    font-size: 14px;
    font-weight: bold;
    color: rgba(43, 43, 43, 0.45);
    background: #fff;
    border-top: 1px dashed #dcdfe6;

    i {
      margin: 0 5px;
    }
  }
</style>
